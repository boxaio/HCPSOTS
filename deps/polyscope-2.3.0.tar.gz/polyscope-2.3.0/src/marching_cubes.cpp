#define MC_IMPLEM_ENABLE
#include "MarchingCube/MC.h"
